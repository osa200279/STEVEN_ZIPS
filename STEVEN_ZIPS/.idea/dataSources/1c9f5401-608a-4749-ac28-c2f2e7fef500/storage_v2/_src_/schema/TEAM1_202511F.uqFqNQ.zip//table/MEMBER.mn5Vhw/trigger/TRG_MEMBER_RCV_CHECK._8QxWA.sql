create trigger TRG_MEMBER_RCV_CHECK
    before insert or update
    on MEMBER
    for each row
BEGIN
    -- SMS 전체 수신 거부(N) 시 하위 항목 강제 N 처리
    IF :NEW.SMS_RCV_YN = 'N' THEN
        :NEW.SMS_NTC_RCV_YN := 'N';
        :NEW.SMS_CTRT_RCV_YN := 'N';
    END IF;

    -- 이메일 전체 수신 거부(N) 시 하위 항목 강제 N 처리
    IF :NEW.EML_RCV_YN = 'N' THEN
        :NEW.EML_NTC_RCV_YN := 'N';
        :NEW.EML_CTRT_RCV_YN := 'N';
    END IF;
END;
/

